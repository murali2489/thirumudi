$(document).ready(function() {
    // Setup - add a text input to each footer cell
    
    var i=0;
    $('#applydtable tfoot th').each( function () {
        if(i!=0){
            
                    
        var title = $(this).text();
        
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    }else {
        
        $(this).html('');
    }
        i++;
        
    } );
 
    // DataTable
    var table =   $('#applydtable').dataTable();

    // Apply the search
    table.columns().every( function () {
        var that = this;
         console('inside');
        
        $( 'input', this.footer() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );
} );