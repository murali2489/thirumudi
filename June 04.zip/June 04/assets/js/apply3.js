$(document).ready(function() {
    // Setup - add a text input to each footer cell

    var i=0;

  $('#applydtable thead tr').clone(true).appendTo( '#applydtable thead' );
    $('#applydtable thead tr:eq(1) th').each( function (i) {
        if(i!=0){


        var title = $(this).text();
        var valtrim = $.trim(title);

        valtrim= valtrim.split(" ").join("").replace("%","percent").replace("$","dollar").replace("/","").replace("#","").concat('s');

           $(this).html( '<input id = "'+valtrim+'ids" type="text" placeholder="Search" />' );
              $( 'input', this ).on( 'keyup change', function () {
		               if ( table.column(i-1).search() !== this.value ) {
		                   table
		                       .column(i-1)
		                       .search( this.value )
		                       .draw();
		               }
        } );
    }else {

        $(this).html('');
    }
        i++;

    } );
   var table = $('#applydtable').DataTable( {
        orderCellsTop: true,
        fixedHeader: true
    } );

    // Apply the search
    table.columns().every( function () {
        var that = this;
         console('inside');

        $( 'input', this.footer() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );




} );


$(document).ready(function() {




$('#refovr').on('click', function(e) {

   $("#myTab").width(2204);
});



$('#refwr').on('click', function(e) {

    $("#myTab").width(1701);
});




$('#refds').on('click', function(e) {

    $("#myTab").width(1585);
});




$('#refjr').on('click', function(e) {

    $("#myTab").width(1639);
});


$('#reftr').on('click', function(e) {

    $("#myTab").width(1405);
});


$('#refms').on('click', function(e) {

    $("#myTab").width(1200);
});




$('#Branchsid').on('click', function(e) {

    e.stopPropagation();
});





	} );
